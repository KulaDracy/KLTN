"""
=============================================================================
Financial Processor - Custom JSON Output Structure
- Processes Vietnamese financial statements
- Outputs hierarchical JSON with custom structure
- Section-based grouping with code hierarchy
=============================================================================
"""

import json
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field
from datetime import datetime
from collections import defaultdict
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# ============================================================================
# VIETNAMESE TEXT PROCESSING
# ============================================================================

class VietnameseTextNormalizer:
    """Vietnamese text normalization utilities"""
    
    @staticmethod
    def normalize(text: str) -> str:
        """Normalize Vietnamese text"""
        if not text:
            return ""
        
        normalized = text.lower().strip()
        normalized = re.sub(r'\s+', ' ', normalized)
        return normalized.strip()
    
    @staticmethod
    def remove_tones(text: str) -> str:
        """Remove Vietnamese tone marks"""
        replacements = {
            'à': 'a', 'á': 'a', 'ả': 'a', 'ã': 'a', 'ạ': 'a',
            'ằ': 'ă', 'ắ': 'ă', 'ẳ': 'ă', 'ẵ': 'ă', 'ặ': 'ă',
            'ầ': 'â', 'ấ': 'â', 'ẩ': 'â', 'ẫ': 'â', 'ậ': 'â',
            'è': 'e', 'é': 'e', 'ẻ': 'e', 'ẽ': 'e', 'ẹ': 'e',
            'ề': 'ê', 'ế': 'ê', 'ể': 'ê', 'ễ': 'ê', 'ệ': 'ê',
            'ì': 'i', 'í': 'i', 'ỉ': 'i', 'ĩ': 'i', 'ị': 'i',
            'ò': 'o', 'ó': 'o', 'ỏ': 'o', 'õ': 'o', 'ọ': 'o',
            'ồ': 'ô', 'ố': 'ô', 'ổ': 'ô', 'ỗ': 'ô', 'ộ': 'ô',
            'ờ': 'ơ', 'ớ': 'ơ', 'ở': 'ơ', 'ỡ': 'ơ', 'ợ': 'ơ',
            'ù': 'u', 'ú': 'u', 'ủ': 'u', 'ũ': 'u', 'ụ': 'u',
            'ừ': 'ư', 'ứ': 'ư', 'ử': 'ư', 'ữ': 'ư', 'ự': 'ư',
            'ỳ': 'y', 'ý': 'y', 'ỷ': 'y', 'ỹ': 'y', 'ỵ': 'y',
            'đ': 'd', 'Đ': 'D'
        }
        
        result = text
        for viet, plain in replacements.items():
            result = result.replace(viet, plain)
        
        return result


class NumberParser:
    """Parse Vietnamese number formats"""
    
    UNIT_MULTIPLIERS = {
        'tỷ': 1_000_000_000,
        'ty': 1_000_000_000,
        'triệu': 1_000_000,
        'trieu': 1_000_000,
        'nghìn': 1_000,
        'nghin': 1_000,
    }
    
    @classmethod
    def parse(cls, value_str: str) -> Optional[float]:
        """Parse Vietnamese number with units"""
        if not value_str or not isinstance(value_str, str):
            return None
        
        # Remove currency symbols
        cleaned = re.sub(
            r'[đĐ$€£¥₫]|VNĐ|VND|USD|EUR|đồng|Dong',
            '',
            value_str,
            flags=re.IGNORECASE
        )
        cleaned = cleaned.strip()
        
        if not cleaned:
            return None
        
        # Extract unit multiplier
        multiplier = 1
        for unit, mult in cls.UNIT_MULTIPLIERS.items():
            if unit in cleaned.lower():
                multiplier = mult
                cleaned = re.sub(unit, '', cleaned, flags=re.IGNORECASE)
                break
        
        # Handle negative
        is_negative = False
        if cleaned.startswith('(') and cleaned.endswith(')'):
            cleaned = cleaned[1:-1]
            is_negative = True
        
        if cleaned.startswith('-'):
            is_negative = True
            cleaned = cleaned[1:]
        
        cleaned = cleaned.strip()
        
        # Handle separators
        dot_count = cleaned.count('.')
        comma_count = cleaned.count(',')
        
        if dot_count == 0 and comma_count == 0:
            try:
                value = float(cleaned) * multiplier
                return -value if is_negative else value
            except ValueError:
                return None
        
        # European format: 1.234.567,89
        if dot_count > 1:
            cleaned = cleaned.replace('.', '')
            cleaned = cleaned.replace(',', '.')
        
        # US format: 1,234,567.89
        elif comma_count > 1:
            cleaned = cleaned.replace(',', '')
        
        # Single separator
        elif dot_count == 1 and comma_count == 0:
            parts = cleaned.split('.')
            if len(parts[-1]) == 3:
                cleaned = cleaned.replace('.', '')
        
        elif comma_count == 1 and dot_count == 0:
            parts = cleaned.split(',')
            if len(parts[-1]) == 3:
                cleaned = cleaned.replace(',', '')
            else:
                cleaned = cleaned.replace(',', '.')
        
        try:
            cleaned = re.sub(r'[^\d.]', '', cleaned)
            value = float(cleaned) * multiplier
            return -value if is_negative else value
        except ValueError:
            return None
    
    @classmethod
    def extract_all_numbers(cls, text: str) -> List[float]:
        """Extract all numbers from text"""
        patterns = re.findall(r'[\d,.\s()+-]+(?:tỷ|triệu|nghìn)?', text, re.IGNORECASE)
        
        numbers = []
        for pattern in patterns:
            num = cls.parse(pattern)
            if num is not None and abs(num) >= 100:  # Filter very small numbers
                numbers.append(num)
        
        return numbers


# ============================================================================
# SECTION MAPPING
# ============================================================================

class SectionMapper:
    """Map Vietnamese section names to standard codes"""
    
    # Section code ranges
    SECTION_CODES = {
        'TÀI SẢN NGẮN HẠN': '100',
        'TÀI SẢN DÀI HẠN': '200',
        'NỢ PHẢI TRẢ': '300',
        'NỢ NGẮN HẠN': '300',
        'NỢ DÀI HẠN': '400',
        'VỐN CHỦ SỞ HỮU': '400',
    }
    
    # Alternative names
    SECTION_ALIASES = {
        'tai san ngan han': 'TÀI SẢN NGẮN HẠN',
        'tai san dai han': 'TÀI SẢN DÀI HẠN',
        'a. tai san ngan han': 'TÀI SẢN NGẮN HẠN',
        'b. tai san dai han': 'TÀI SẢN DÀI HẠN',
        'no phai tra': 'NỢ PHẢI TRẢ',
        'no ngan han': 'NỢ NGẮN HẠN',
        'no dai han': 'NỢ DÀI HẠN',
        'von chu so huu': 'VỐN CHỦ SỞ HỮU',
        'c. von chu so huu': 'VỐN CHỦ SỞ HỮU',
        'current assets': 'TÀI SẢN NGẮN HẠN',
        'non-current assets': 'TÀI SẢN DÀI HẠN',
        'liabilities': 'NỢ PHẢI TRẢ',
        'equity': 'VỐN CHỦ SỞ HỮU',
    }
    
    @classmethod
    def detect_section(cls, text: str) -> Optional[Tuple[str, str]]:
        """
        Detect section from text
        Returns: (section_name, section_code) or None
        """
        text_clean = VietnameseTextNormalizer.normalize(text)
        text_clean = re.sub(r'^[A-Z]\.?\s*', '', text_clean)  # Remove A. B. C.
        
        # Try exact match
        for section_name, section_code in cls.SECTION_CODES.items():
            if section_name.lower() in text_clean:
                return (section_name, section_code)
        
        # Try aliases
        for alias, section_name in cls.SECTION_ALIASES.items():
            if alias in text_clean:
                section_code = cls.SECTION_CODES.get(section_name)
                return (section_name, section_code)
        
        return None


# ============================================================================
# DATA STRUCTURES
# ============================================================================

@dataclass
class LineItem:
    """A single line item with code and values"""
    code: str
    name: str
    values: Dict[str, float]  # {date: value}
    level: int = 0
    metadata: Dict = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        """Convert to dictionary"""
        return {
            'code': self.code,
            'name': self.name,
            'values': self.values
        }


@dataclass
class Section:
    """A financial statement section"""
    section: str
    code: str
    items: List[LineItem] = field(default_factory=list)
    
    def to_dict(self) -> Dict:
        """Convert to dictionary matching desired output format"""
        return {
            'section': self.section,
            'code': self.code,
            'items': [item.to_dict() for item in self.items]
        }


# ============================================================================
# FINANCIAL PROCESSOR
# ============================================================================

class FinancialProcessor:
    """
    Process OCR JSON and output structured financial data
    """
    
    def __init__(self):
        self.parser = NumberParser()
        self.section_mapper = SectionMapper()
        self.current_section = None
        self.current_section_code = None
        
        # Store dates found in document
        self.dates = []
        
        logger.info("Financial Processor initialized")
    
    def process_ocr_json(self, json_path: str) -> Dict:
        """
        Process OCR JSON file
        
        Args:
            json_path: Path to OCR JSON
            
        Returns:
            Structured financial data
        """
        logger.info(f"Processing: {json_path}")
        
        # Load OCR data
        with open(json_path, 'r', encoding='utf-8') as f:
            ocr_data = json.load(f)
        
        # Extract metadata
        company_name = self._extract_company_name(ocr_data)
        self.dates = self._extract_dates(ocr_data)
        currency = self._extract_currency(ocr_data)
        
        # Extract all sections and items
        sections = []
        
        pages = ocr_data.get('pages', {})
        for page_key, page_data in sorted(pages.items()):
            page_sections = self._extract_sections_from_page(page_data)
            sections.extend(page_sections)
        
        # Merge sections with same code
        merged_sections = self._merge_sections(sections)
        
        logger.info(f"Extracted {len(merged_sections)} sections")
        
        # Build output structure
        output = {
            'company_name': company_name,
            'report_dates': self.dates,
            'currency': currency,
            'generated_at': datetime.now().isoformat(),
            'sections': [section.to_dict() for section in merged_sections]
        }
        
        return output
    
    def _extract_company_name(self, ocr_data: Dict) -> Optional[str]:
        """Extract company name"""
        pages = ocr_data.get('pages', {})
        for page_data in pages.values():
            content = page_data.get('content', '')
            
            for line in content.split('\n')[:15]:
                if 'công ty' in line.lower() or 'cong ty' in line.lower():
                    return line.strip()
        
        return None
    
    def _extract_dates(self, ocr_data: Dict) -> List[str]:
        """Extract report dates"""
        dates = []
        
        pages = ocr_data.get('pages', {})
        for page_data in pages.values():
            content = page_data.get('content', '')
            
            # Find dates in format DD/MM/YYYY
            date_matches = re.findall(r'\d{2}/\d{2}/\d{4}', content)
            
            for date in date_matches:
                if date not in dates:
                    dates.append(date)
            
            if len(dates) >= 2:
                break
        
        return dates
    
    def _extract_currency(self, ocr_data: Dict) -> str:
        """Extract currency"""
        pages = ocr_data.get('pages', {})
        for page_data in pages.values():
            content = page_data.get('content', '').lower()
            
            if any(hint in content for hint in ['vnd', 'đồng', 'dong']):
                return 'VND'
            elif 'usd' in content:
                return 'USD'
        
        return 'VND'
    
    def _extract_sections_from_page(self, page_data: Dict) -> List[Section]:
        """Extract sections from a page"""
        content = page_data.get('content', '')
        sections = []
        current_section = None
        
        for line in content.split('\n'):
            line = line.strip()
            if not line:
                continue
            
            # Check if this is a section header
            section_info = self.section_mapper.detect_section(line)
            
            if section_info:
                # Save previous section
                if current_section and current_section.items:
                    sections.append(current_section)
                
                # Start new section
                section_name, section_code = section_info
                current_section = Section(
                    section=section_name,
                    code=section_code
                )
                
                self.current_section = section_name
                self.current_section_code = section_code
                
                logger.info(f"Found section: {section_name} (code: {section_code})")
                continue
            
            # Try to parse as line item
            if current_section:
                item = self._parse_line_item(line)
                if item:
                    current_section.items.append(item)
        
        # Add last section
        if current_section and current_section.items:
            sections.append(current_section)
        
        return sections
    
    def _parse_line_item(self, line: str) -> Optional[LineItem]:
        """Parse a line into LineItem"""
        
        # Extract code (3 digits at start)
        code_match = re.match(r'^\s*(\d{2,3})\s+(.+)', line)
        
        if not code_match:
            return None
        
        code = code_match.group(1)
        rest = code_match.group(2)
        
        # Extract numbers (values for different dates)
        numbers = self.parser.extract_all_numbers(rest)
        
        if not numbers:
            return None
        
        # Remove numbers from rest to get name
        name = rest
        for num_str in re.findall(r'[\d,.\s()+-]+', rest):
            name = name.replace(num_str, '')
        
        # Clean name
        name = re.sub(r'\s+', ' ', name).strip()
        name = re.sub(r'[:\-]+$', '', name).strip()
        
        if len(name) < 3:
            return None
        
        # Build values dict with dates
        values = {}
        
        if len(self.dates) >= 1 and len(numbers) >= 1:
            values[self.dates[0]] = numbers[0]
        
        if len(self.dates) >= 2 and len(numbers) >= 2:
            values[self.dates[1]] = numbers[1]
        
        # If we have numbers but no dates yet, use placeholder
        if not values and numbers:
            for i, num in enumerate(numbers[:2]):
                values[f"Column_{i+1}"] = num
        
        # Determine hierarchy level
        level = self._detect_level(code)
        
        return LineItem(
            code=code,
            name=name,
            values=values,
            level=level
        )
    
    def _detect_level(self, code: str) -> int:
        """Detect hierarchy level from code"""
        if not code or not code.isdigit():
            return 0
        
        # 100, 200, 300 -> level 0 (section header)
        if code.endswith('00'):
            return 0
        # 110, 120, 130 -> level 1
        elif code.endswith('0'):
            return 1
        # 111, 121, 131 -> level 2
        else:
            return 2
    
    def _merge_sections(self, sections: List[Section]) -> List[Section]:
        """Merge sections with same code"""
        merged = {}
        
        for section in sections:
            key = section.code
            
            if key in merged:
                # Merge items
                merged[key].items.extend(section.items)
            else:
                merged[key] = section
        
        # Sort by code
        return sorted(merged.values(), key=lambda s: s.code)
    
    def export_to_json(self, data: Dict, output_path: str):
        """Export to JSON file"""
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        logger.info(f"Exported to: {output_path}")
    
    def export_to_compact_json(self, data: Dict, output_path: str):
        """Export to compact JSON (no metadata)"""
        # Extract only sections
        compact_data = data.get('sections', [])
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(compact_data, f, ensure_ascii=False, indent=2)
        
        logger.info(f"Exported compact to: {output_path}")


# ============================================================================
# MAIN / USAGE
# ============================================================================

def main():
    """Main function"""
    import sys
    
    if len(sys.argv) < 2:
        print("="*70)
        print("FINANCIAL PROCESSOR - Custom JSON Output")
        print("="*70)
        print("\nUsage:")
        print("  python financial_processor_custom_output.py <ocr_json_path>")
        print("\nExample:")
        print("  python financial_processor_custom_output.py balance_sheet.json")
        print("\nOutput:")
        print("  - <input>_structured.json : Full output with metadata")
        print("  - <input>_compact.json    : Sections only (like your example)")
        print("="*70)
        sys.exit(1)
    
    input_json = sys.argv[1]
    
    if not Path(input_json).exists():
        print(f"❌ Error: File not found: {input_json}")
        sys.exit(1)
    
    output_structured = input_json.replace('.json', '_structured.json')
    output_compact = input_json.replace('.json', '_compact.json')
    
    print("\n" + "="*70)
    print("FINANCIAL PROCESSOR - Custom JSON Output")
    print("="*70)
    print(f"\n📁 Input:  {input_json}")
    print(f"📄 Output: {output_structured}")
    print(f"📦 Compact: {output_compact}")
    print("\n" + "-"*70)
    
    try:
        # Initialize processor
        processor = FinancialProcessor()
        
        # Process
        print("\n⚙️  Processing OCR data...")
        result = processor.process_ocr_json(input_json)
        
        # Export full version
        print("💾 Exporting structured JSON...")
        processor.export_to_json(result, output_structured)
        
        # Export compact version
        print("📦 Exporting compact JSON...")
        processor.export_to_compact_json(result, output_compact)
        
        # Print summary
        print("\n" + "="*70)
        print("PROCESSING SUMMARY")
        print("="*70)
        
        print(f"\n🏢 Company: {result.get('company_name', 'N/A')}")
        print(f"📅 Dates: {', '.join(result.get('report_dates', []))}")
        print(f"💰 Currency: {result.get('currency', 'N/A')}")
        
        sections = result.get('sections', [])
        print(f"\n📊 Sections Found: {len(sections)}")
        
        total_items = 0
        for section in sections:
            items_count = len(section.get('items', []))
            total_items += items_count
            print(f"  • [{section.get('code')}] {section.get('section')}: {items_count} items")
        
        print(f"\n📝 Total Items: {total_items}")
        
        # Show sample output
        print("\n" + "="*70)
        print("SAMPLE OUTPUT (first section):")
        print("="*70)
        
        if sections:
            sample = sections[0]
            sample_json = json.dumps(sample, ensure_ascii=False, indent=2)
            
            # Limit to first 3 items for display
            if 'items' in sample and len(sample['items']) > 3:
                sample['items'] = sample['items'][:3]
                sample_json = json.dumps(sample, ensure_ascii=False, indent=2)
                sample_json += "\n  ... (more items)"
            
            print(sample_json)
        
        print("\n" + "="*70)
        print("✅ PROCESSING COMPLETE!")
        print("="*70)
        
    except Exception as e:
        print(f"\n❌ Error: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()