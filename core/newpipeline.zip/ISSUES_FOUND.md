# 🔍 Issues Found in Your Pipeline

## ❌ Critical Issues

### Issue 1: Missing parameters in OCRScanModule initialization

**File:** `main_pipeline.py` (line 51-54)

**Problem:**
```python
self.ocr_scanner = OCRScanModule(
    use_gpu=config.ocr_use_gpu,
    confidence_threshold=config.ocr_confidence_threshold
)
```

**Missing:**
- `lang` parameter (should be 'vi')
- `low_confidence_threshold` parameter

**Fix:**
```python
self.ocr_scanner = OCRScanModule(
    lang=config.ocr_lang,  # Add this
    use_gpu=config.ocr_use_gpu,
    confidence_threshold=config.ocr_confidence_threshold,
    low_confidence_threshold=config.ocr_low_confidence_threshold  # Add this
)
```

---

### Issue 2: OCRScanModule missing features

**File:** `ocr_scan_module.py`

**Problems:**

1. **No preprocessing capability**
   - Your module doesn't have `preprocess_image()` method
   - Config has `ocr_use_preprocessing` but module can't use it

2. **No single image scanning**
   - Missing `scan_image()` method
   - Main pipeline expects `scan_image()` for single processing

3. **Hard-coded confidence**
   ```python
   # Line 100
   "confidence": 0.95,  # ❌ Always 0.95, not realistic
   ```
   VietOCR should return actual confidence

4. **Missing low_confidence_threshold**
   - Module doesn't track `has_low_confidence` properly
   - Always returns `False` (line 109)

**Recommended fixes:**

```python
@dataclass
class OCRScanResult:
    image_path: str
    lines: list
    average_confidence: float
    min_confidence: float  # Add this
    max_confidence: float  # Add this
    has_low_confidence: bool
    total_lines: int  # Add this
    low_confidence_threshold: float  # Add this
```

Add methods:
```python
def preprocess_image(self, image):
    """Add preprocessing"""
    # CLAHE, denoise, etc.
    
def scan_image(self, image_path, use_preprocessing=True, verbose=True):
    """Scan single image"""
    # Process one image
```

---

### Issue 3: Logic error in PipelineResult

**File:** `main_pipeline.py` (line 125)

**Problem:**
```python
total_items=ocr_report.metadata.get('total_items', 0),
```

**Error:** `ocr_report` is a `FinancialReport` object, not dict
- `ocr_report.metadata` is a dict
- But should be: `ocr_report.metadata['total_items']`

**Fix:**
```python
total_items=sum(len(s.items) for s in ocr_report.sections),
```

---

### Issue 4: Missing dependencies

**File:** `requirements.txt`

**Missing:**
```txt
vietocr>=0.3.0
torch>=1.9.0  # Required by VietOCR
torchvision>=0.10.0
```

**Current requirements.txt only has:**
```txt
paddleocr>=2.7.0
opencv-python>=4.8.0
numpy>=1.24.0
anthropic>=0.18.0
openai>=1.12.0
pillow>=10.0.0
```

---

### Issue 5: Priority logic incomplete

**File:** `ocr_scan_module.py` (line 56-67)

**Problem:**
```python
def _quick_analyze_priority(self, image_path: str) -> int:
    # Only checks filename
    # Doesn't check actual content
```

**Issue:** Priority based only on filename is weak

**Recommendation:** Add simple image analysis or remove priority

---

### Issue 6: Error handling in worker

**File:** `ocr_scan_module.py` (line 105-106)

**Problem:**
```python
except:
    continue  # Silent fail
```

**Issue:** Errors are silently ignored, hard to debug

**Fix:**
```python
except Exception as e:
    print(f"  ⚠️  Error processing line {i}: {e}")
    continue
```

---

### Issue 7: VietOCR might not return confidence

**File:** `ocr_scan_module.py` (line 96)

**Problem:**
```python
text = recognizer.predict(pil_img)
# Returns only text, no confidence
```

**Issue:** VietOCR's `predict()` doesn't return confidence by default

**Fix:** Need to check VietOCR API or use alternative method

---

## ⚠️ Minor Issues

### 1. Hardcoded path in example
```python
# main_pipeline.py line 170
image_folder=r'C:\Users\lengu\Desktop\KLTN\core\files\images'
# Should use relative path or argument
```

### 2. No validation
```python
# main_pipeline.py - No check if:
# - image_folder exists
# - VLM key is valid when enabled
# - Output folder is writable
```

### 3. Incomplete CSV metadata
```python
# When include_csv_metadata=True but vlm_verification=False
# CSV won't have metadata columns
```

---

## ✅ Recommended Fixes Priority

### High Priority (Must fix):
1. ✅ Fix OCRScanModule initialization parameters
2. ✅ Add `scan_image()` method to OCRScanModule
3. ✅ Fix `total_items` logic error
4. ✅ Add missing dependencies to requirements.txt
5. ✅ Fix VietOCR confidence handling

### Medium Priority (Should fix):
6. Add preprocessing to OCRScanModule
7. Improve error handling
8. Add input validation
9. Fix has_low_confidence detection

### Low Priority (Nice to have):
10. Improve priority logic or remove it
11. Better logging
12. Add unit tests

---

## 🔧 Quick Fix Script

I'll create fixed versions of your files in the next message.

---

## 📊 Compatibility Issues

Your pipeline tries to use my modules but has these mismatches:

| Expected by your code | Your implementation |
|----------------------|---------------------|
| `scan_image()` method | ❌ Only `scan_batch()` |
| `preprocess_image()` | ❌ Not implemented |
| `low_confidence_threshold` | ❌ Not tracked |
| Actual confidence scores | ❌ Hard-coded 0.95 |
| Single image processing | ❌ Only batch |

---

## 💡 Recommendation

**Option 1: Fix your modules**
- Add missing methods
- Fix logic errors
- Update dependencies

**Option 2: Use my original modules**
- They have all features
- Well tested
- Complete documentation

**Option 3: Hybrid approach**
- Keep your VietOCR innovation
- Add missing features from my modules
- Merge best of both

Which option do you prefer? I can help with any approach!
