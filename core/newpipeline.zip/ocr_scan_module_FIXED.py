"""
ocr_scan_module_FIXED.py
Fixed version với tất cả features cần thiết
"""

import cv2
import numpy as np
import threading
import queue
import json
from pathlib import Path
from typing import List, Dict, Optional
from dataclasses import dataclass, asdict
from PIL import Image

# Import Models
from paddleocr import PaddleOCR
try:
    from vietocr.tool.predictor import Predictor
    from vietocr.tool.config import Cfg
    VIETOCR_AVAILABLE = True
except ImportError:
    VIETOCR_AVAILABLE = False
    print("⚠️  VietOCR not available, using PaddleOCR only")


@dataclass
class BoundingBox:
    """Bounding box info"""
    x_min: float
    y_min: float
    x_max: float
    y_max: float
    
    def to_dict(self):
        return asdict(self)


@dataclass
class OCRLine:
    """OCR line with full metadata"""
    text: str
    confidence: float
    bbox: BoundingBox
    line_number: int
    y_position: float
    
    def to_dict(self):
        return {
            'text': self.text,
            'confidence': self.confidence,
            'bbox': self.bbox.to_dict(),
            'line_number': self.line_number,
            'y_position': self.y_position
        }


@dataclass
class OCRScanResult:
    """Kết quả scan với đầy đủ thông tin"""
    image_path: str
    total_lines: int
    average_confidence: float
    min_confidence: float
    max_confidence: float
    lines: List[OCRLine]
    has_low_confidence: bool
    low_confidence_threshold: float
    
    def to_dict(self):
        return {
            'image_path': self.image_path,
            'total_lines': self.total_lines,
            'average_confidence': self.average_confidence,
            'min_confidence': self.min_confidence,
            'max_confidence': self.max_confidence,
            'has_low_confidence': self.has_low_confidence,
            'low_confidence_threshold': self.low_confidence_threshold,
            'lines': [line.to_dict() for line in self.lines]
        }


class OCRScanModule:
    """
    OCR Scan Module với VietOCR + PaddleOCR
    
    Features:
    - Hybrid: PaddleOCR (detect) + VietOCR (recognize)
    - Multi-threading support
    - Preprocessing
    - Confidence tracking
    - Single + Batch processing
    """
    
    def __init__(self, 
                 lang='vi',
                 use_gpu=False,
                 num_workers=2,
                 confidence_threshold=0.6,
                 low_confidence_threshold=0.5):
        """
        Initialize OCR Scan Module
        
        Args:
            lang: Language ('vi' for Vietnamese)
            use_gpu: Use GPU
            num_workers: Number of threads for batch
            confidence_threshold: Min confidence to keep text
            low_confidence_threshold: Threshold to trigger VLM fallback
        """
        self.lang = lang
        self.use_gpu = use_gpu
        self.num_workers = num_workers
        self.confidence_threshold = confidence_threshold
        self.low_confidence_threshold = low_confidence_threshold
        
        # Thread-local storage
        self._local = threading.local()
        
        # Queue system
        self.task_queue = queue.PriorityQueue()
        self.results_map = {}
        self.results_lock = threading.Lock()
        self.stop_event = threading.Event()
        
        print(f"✓ OCR Scan Module initialized")
        print(f"  Language: {lang}")
        print(f"  VietOCR: {'Available' if VIETOCR_AVAILABLE else 'Not available'}")
        print(f"  Confidence threshold: {confidence_threshold}")
        print(f"  Low confidence threshold: {low_confidence_threshold}")
    
    def _init_models(self):
        """Initialize models for each thread"""
        if not hasattr(self._local, 'detector'):
            # PaddleOCR for detection
            self._local.detector = PaddleOCR(
                use_angle_cls=True,
                lang=self.lang,
                det=True,
                rec=not VIETOCR_AVAILABLE,  # Use PaddleOCR rec if VietOCR unavailable
                use_gpu=self.use_gpu,
                show_log=False
            )
            
            # VietOCR for recognition (if available)
            if VIETOCR_AVAILABLE:
                config = Cfg.load_config_from_name('vgg_transformer')
                config['device'] = 'cuda' if self.use_gpu else 'cpu'
                config['predictor']['beamsearch'] = False  # Faster
                self._local.recognizer = Predictor(config)
            else:
                self._local.recognizer = None
        
        return self._local.detector, self._local.recognizer
    
    def preprocess_image(self, image: np.ndarray) -> np.ndarray:
        """
        Preprocess image for better OCR
        
        Args:
            image: Input image (BGR)
            
        Returns:
            Preprocessed image
        """
        # Convert to grayscale
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image
        
        # Denoise
        denoised = cv2.fastNlMeansDenoising(
            gray, None,
            h=10,
            templateWindowSize=7,
            searchWindowSize=21
        )
        
        # CLAHE
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        enhanced = clahe.apply(denoised)
        
        # Adaptive threshold
        binary = cv2.adaptiveThreshold(
            enhanced, 255,
            cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
            cv2.THRESH_BINARY,
            11, 2
        )
        
        # Convert back to BGR
        return cv2.cvtColor(binary, cv2.COLOR_GRAY2BGR)
    
    def _process_single_image(self,
                             image_path: str,
                             detector,
                             recognizer,
                             use_preprocessing: bool = True) -> OCRScanResult:
        """
        Core OCR logic for single image
        
        Args:
            image_path: Path to image
            detector: PaddleOCR detector
            recognizer: VietOCR recognizer or None
            use_preprocessing: Apply preprocessing
            
        Returns:
            OCRScanResult
        """
        # Load image
        img = cv2.imread(image_path)
        if img is None:
            return OCRScanResult(
                image_path=image_path,
                total_lines=0,
                average_confidence=0.0,
                min_confidence=0.0,
                max_confidence=0.0,
                lines=[],
                has_low_confidence=True,
                low_confidence_threshold=self.low_confidence_threshold
            )
        
        # Preprocessing
        if use_preprocessing:
            img = self.preprocess_image(img)
        
        # Detection
        if recognizer:
            # Use PaddleOCR for detection only
            raw_result = detector.ocr(img, det=True, rec=False, cls=True)
        else:
            # Use PaddleOCR for both detection and recognition
            raw_result = detector.ocr(img, det=True, rec=True, cls=True)
        
        if not raw_result or raw_result[0] is None:
            return OCRScanResult(
                image_path=image_path,
                total_lines=0,
                average_confidence=0.0,
                min_confidence=0.0,
                max_confidence=0.0,
                lines=[],
                has_low_confidence=True,
                low_confidence_threshold=self.low_confidence_threshold
            )
        
        # Process results
        ocr_lines = []
        confidences = []
        h_img, w_img = img.shape[:2]
        
        result = raw_result[0]
        
        for i, box in enumerate(result):
            try:
                # Extract bbox
                if recognizer:
                    # VietOCR mode: box is just coordinates
                    points_raw = box if isinstance(box, (list, np.ndarray)) else box[0]
                else:
                    # PaddleOCR mode: box has [coords, (text, conf)]
                    points_raw = box[0]
                
                points = np.array(points_raw, dtype=np.float32).reshape(-1, 2).astype(np.int32)
                x_min, y_min = np.min(points, axis=0)
                x_max, y_max = np.max(points, axis=0)
                
                # Create bbox
                bbox = BoundingBox(
                    x_min=float(x_min),
                    y_min=float(y_min),
                    x_max=float(x_max),
                    y_max=float(y_max)
                )
                
                # Get text and confidence
                if recognizer:
                    # Crop and recognize with VietOCR
                    crop = img[max(0, y_min-2):min(h_img, y_max+2),
                              max(0, x_min-2):min(w_img, x_max+2)]
                    
                    if crop.size == 0:
                        continue
                    
                    pil_img = Image.fromarray(cv2.cvtColor(crop, cv2.COLOR_BGR2RGB))
                    text = recognizer.predict(pil_img)
                    # VietOCR doesn't return confidence, use high default
                    confidence = 0.90
                else:
                    # PaddleOCR mode
                    text = box[1][0]
                    confidence = float(box[1][1])
                
                # Filter by confidence
                if confidence >= self.confidence_threshold:
                    ocr_line = OCRLine(
                        text=text,
                        confidence=confidence,
                        bbox=bbox,
                        line_number=i + 1,
                        y_position=(bbox.y_min + bbox.y_max) / 2
                    )
                    ocr_lines.append(ocr_line)
                    confidences.append(confidence)
                
            except Exception as e:
                print(f"  ⚠️  Error processing line {i}: {e}")
                continue
        
        # Sort by y position
        ocr_lines.sort(key=lambda x: x.y_position)
        
        # Calculate statistics
        if confidences:
            avg_confidence = sum(confidences) / len(confidences)
            min_confidence = min(confidences)
            max_confidence = max(confidences)
        else:
            avg_confidence = 0.0
            min_confidence = 0.0
            max_confidence = 0.0
        
        # Check if has low confidence
        has_low_confidence = (
            avg_confidence < self.low_confidence_threshold or
            min_confidence < self.low_confidence_threshold * 0.8
        )
        
        return OCRScanResult(
            image_path=image_path,
            total_lines=len(ocr_lines),
            average_confidence=avg_confidence,
            min_confidence=min_confidence,
            max_confidence=max_confidence,
            lines=ocr_lines,
            has_low_confidence=has_low_confidence,
            low_confidence_threshold=self.low_confidence_threshold
        )
    
    def scan_image(self,
                  image_path: str,
                  use_preprocessing: bool = True,
                  verbose: bool = True) -> OCRScanResult:
        """
        Scan single image
        
        Args:
            image_path: Path to image
            use_preprocessing: Apply preprocessing
            verbose: Show logs
            
        Returns:
            OCRScanResult
        """
        if verbose:
            print(f"\n{'='*70}")
            print(f"OCR SCANNING: {Path(image_path).name}")
            print(f"{'='*70}")
        
        # Initialize models
        detector, recognizer = self._init_models()
        
        # Process
        result = self._process_single_image(
            image_path,
            detector,
            recognizer,
            use_preprocessing
        )
        
        if verbose:
            print(f"\n📊 Scan Results:")
            print(f"  Total lines: {result.total_lines}")
            print(f"  Average confidence: {result.average_confidence:.2%}")
            print(f"  Min confidence: {result.min_confidence:.2%}")
            print(f"  Max confidence: {result.max_confidence:.2%}")
            
            if result.has_low_confidence:
                print(f"  ⚠️  LOW CONFIDENCE - Will trigger VLM fallback")
            else:
                print(f"  ✓ Confidence OK")
            
            print(f"{'='*70}\n")
        
        return result
    
    def _quick_analyze_priority(self, image_path: str) -> int:
        """Analyze priority (simple filename-based)"""
        try:
            name = Path(image_path).stem.lower()
            if any(k in name for k in ['page_001', 'balance', 'kqkd', 'tc', 'sheet']):
                return 1  # High priority
            return 5  # Normal
        except:
            return 10  # Low priority
    
    def _worker(self):
        """Worker thread loop"""
        detector, recognizer = self._init_models()
        
        while not self.stop_event.is_set():
            try:
                priority, img_path = self.task_queue.get(timeout=1)
                
                result = self._process_single_image(
                    img_path,
                    detector,
                    recognizer,
                    use_preprocessing=True
                )
                
                with self.results_lock:
                    self.results_map[img_path] = result
                
                self.task_queue.task_done()
                print(f"  ✓ {Path(img_path).name} | Conf: {result.average_confidence:.2%}")
                
            except queue.Empty:
                continue
            except Exception as e:
                print(f"  ❌ Worker error: {e}")
                self.task_queue.task_done()
    
    def scan_batch(self,
                  image_folder: str,
                  verbose: bool = True) -> List[OCRScanResult]:
        """
        Scan batch of images with multi-threading
        
        Args:
            image_folder: Folder containing images
            verbose: Show logs
            
        Returns:
            List of OCRScanResult
        """
        # Find images
        img_paths = []
        for ext in ['.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.tif']:
            img_paths.extend(Path(image_folder).glob(f'*{ext}'))
        
        img_paths = [str(p) for p in sorted(img_paths)]
        
        if not img_paths:
            print(f"⚠️  No images found in {image_folder}")
            return []
        
        if verbose:
            print(f"\n🚀 Multi-thread Hybrid OCR")
            print(f"  Workers: {self.num_workers}")
            print(f"  Images: {len(img_paths)}")
        
        # Add to queue with priority
        for path in img_paths:
            priority = self._quick_analyze_priority(path)
            self.task_queue.put((priority, path))
        
        # Start workers
        threads = []
        for i in range(self.num_workers):
            t = threading.Thread(target=self._worker, daemon=True)
            t.start()
            threads.append(t)
        
        # Wait for completion
        self.task_queue.join()
        self.stop_event.set()
        for t in threads:
            t.join()
        
        # Return results in original order
        results = [self.results_map[p] for p in img_paths if p in self.results_map]
        
        if verbose:
            success = len(results)
            low_conf = sum(1 for r in results if r.has_low_confidence)
            print(f"\n✓ Batch scan completed")
            print(f"  Success: {success}/{len(img_paths)}")
            print(f"  Low confidence: {low_conf}")
        
        return results
    
    def save_scan_result(self,
                        scan_result: OCRScanResult,
                        output_path: str,
                        verbose: bool = False):
        """
        Save scan result to JSON
        
        Args:
            scan_result: OCRScanResult to save
            output_path: Output JSON path
            verbose: Show logs
        """
        data = scan_result.to_dict()
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        if verbose:
            print(f"✓ Scan result saved: {output_path}")


# Example usage
if __name__ == "__main__":
    scanner = OCRScanModule(
        lang='vi',
        use_gpu=False,
        confidence_threshold=0.6,
        low_confidence_threshold=0.5
    )
    
    # Single image
    result = scanner.scan_image('test.png', verbose=True)
    scanner.save_scan_result(result, 'scan_result.json')
    
    # Batch
    # results = scanner.scan_batch('./images', verbose=True)
